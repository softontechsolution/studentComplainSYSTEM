<?php

include "db.php";

if (isset($_POST['dog']))
{
	$email=   $_POST['email'];
	$password=  $_POST['password'];

if (strlen($email)<2 || strlen($password)<2){
	header('location:index.php');
}else{
	$query= "SELECT * FROM register WHERE email ='$email' AND password ='$password' ";
	$querit = mysqli_query($db,$query) or die($db->error);
			if(mysqli_num_rows($querit)>=1){
				header('location:admin/indexx.php');
			}else{
				header('location:index.php');
			}

	}
}


?> 