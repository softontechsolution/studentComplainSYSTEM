<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/

-->

<?php include"../db.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Easy Admin Panel an Admin Panel Category Flat Bootstrap Responsive Website Template | Inbox :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Easy Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!----webfonts--->
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<!---//webfonts---> 
 <!-- Meters graphs -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- Placed js at the end of the document so the pages load faster -->

</head> 
   
 <body class="sticky-header left-side-collapsed"  onload="initMap()">
    <section>
    <!-- left side start-->
		<div class="left-side sticky-left-side">

			<!--logo and iconic logo start-->
			<div class="logo">
				<h1><a href="index.html">Easy <span>Admin</span></a></h1>
			</div>
			<div class="logo-icon text-center">
				<a href="index.html"><i class="lnr lnr-home"></i> </a>
			</div>

			<!--logo and iconic logo end-->
			<div class="left-side-inner">

				<!--sidebar nav start-->
					<ul class="nav nav-pills nav-stacked custom-nav">
						<li class="active"><a href="index.php"><i class="lnr lnr-power-switch"></i><span>Dashboard</span></a></li>
						<li class="menu-list">
							<a href="#"><i class="lnr lnr-cog"></i>
								<span>Complains</span></a>
								<ul class="sub-menu-list">
									<li><a href="view_complain.php">Total Complains</a> </li>
									<li><a href="view_complain.php">Unresponded Complains</a></li>
									<li><a href="sign-up.html">Add Staff</a></li>
									<li><a href="admin/indexx.php">Log Out</a></li>
								</ul>
						
				<!--sidebar nav end-->
			</div>
		</div>
    <!-- left side end-->
    
    <!-- main content start-->
		<div class="main-content">
			<!-- header-starts -->
			<div class="header-section">
			 
			<!--toggle button start-->
			<a class="toggle-btn  menu-collapsed"><i class="fa fa-bars"></i></a>
			<!--toggle button end-->

			<!--notification menu start -->
			
			<!--notification menu end -->
			</div>
	<!-- //header-ends -->
			<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Complains</h3>

				
						<div class="col-md-12 span_20">
							<div class="activity_box">
								<h3>Complains</h3>
								<div class="scrollbar scrollbar1" id="style-2">
									<?php
									$query = "SELECT * FROM complain_table WHERE complain_id >= 1";
									$run_query = mysqli_query($db, $query);
									$serial_number = 1;
									while ($row = mysqli_fetch_assoc($run_query)):
										$complain_id = $row['complain_id'];
									    $fname = $row['fname'];
									    $complain = $row['complain'];
									?>
		
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><?php echo $serial_number++?></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="attend.html"><?php echo $fname?></a></h5>
											<p><?php echo $complain?></p>
										</div>
										<div class="col-xs-2 activity-desc1"><a href="attend.php?complainer_id=<?php echo $complain_id; ?>" class="btn btn-info" >Respond</a></div>
										<div class="clearfix"> </div>
									</div>
									<?php
									endwhile;
									?>


									<!-- <div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/5.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="#">Andrew Jos</a></h5>
											<p>Hey ! There I'm available.</p>
										</div>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div>
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/3.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="#">Adom Smith</a></h5>
											<p>Hey ! There I'm available.</p>
										</div>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div>
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/4.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="#">Peter Carl</a></h5>
											<p>Hey ! There I'm available.</p>
										</div>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div>
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/1.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="#">John Smith</a></h5>
											<p>Hey ! There I'm available.</p>
										</div>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div> -->
								</div>
							</div>
						</div>
					

						<div class="clearfix"> </div>
						
					
				</div>
			</div>
		</div>
		<!--footer section start-->
			<footer>
			   <
			</footer>
        <!--footer section end-->
	</section>
	
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>