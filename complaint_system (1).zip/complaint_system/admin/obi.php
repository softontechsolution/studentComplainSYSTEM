<?php
$host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbase = 'koko';

   $db = mysqli_connect($host,$user,$pass,$dbase) or die(mysqli_error());
    mysqli_select_db($db,$dbase);

?>