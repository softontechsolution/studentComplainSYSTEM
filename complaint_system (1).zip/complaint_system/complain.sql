-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2018 at 03:58 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `koko`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(225) NOT NULL AUTO_INCREMENT,
  `user` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `complain_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `complain` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `user`, `password`, `email`, `complain_id`, `name`, `complain`) VALUES
(1, 'obi', '8e248757798f5833d3d6da545cb550db', 'obi@gmail.com', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `complain_table`
--

CREATE TABLE IF NOT EXISTS `complain_table` (
  `complain_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(225) NOT NULL,
  `lname` varchar(225) NOT NULL,
  `department` varchar(225) NOT NULL,
  `faculty` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `phone` varchar(225) NOT NULL,
  `nature_of_complain` varchar(225) NOT NULL,
  `complain` varchar(225) NOT NULL,
  `attended` int(5) NOT NULL,
  `complain_attended` varchar(255) NOT NULL,
  PRIMARY KEY (`complain_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `complain_table`
--

INSERT INTO `complain_table` (`complain_id`, `fname`, `lname`, `department`, `faculty`, `email`, `phone`, `nature_of_complain`, `complain`, `attended`, `complain_attended`) VALUES
(1, 'osas', 'osas', 'Agricultural Economics and Extension', 'Falcuty of Science', 'osas@yahoo.com', '09090989876', 'Departmental Complain', 'opy 2015 Easy Admin Panel. All Rights Reserved | Design by', 1, 'Seen, Responds coming shortly.'),
(2, 'okonn', 'israel', 'Agricultural Economics and Extension', 'Falcuty of Science', 'joee@yahoo.com', '08090989876', 'Departmental Complain', 'opy 2015 Easy Admin Panel. All Rights Reserved | Design by', 1, 'ok'),
(3, 'complain', 'complain', 'Agricultural Economics and Extension', 'Falcuty of Science', 'complain@yahoo.com', '09098098908', 'Departmental Complain', 'okay ! thanks ..', 1, 'OKOKOK'),
(4, 'complain', 'complain', 'Agricultural Economics and Extension', 'Falcuty of Science', 'complain@yahoo.com', '09098098908', 'Departmental Complain', 'okay ! thanks ..', 0, ''),
(5, 'Joseph', 'Nnamoko', 'Agricultural Economics and Extension', 'Faculty of Arts', 'someone@yahoo.com', '09089474844', 'Departmental Complain', 'No light in the Hostel.', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `reg_id` int(225) NOT NULL AUTO_INCREMENT,
  `fname` varchar(225) NOT NULL,
  `lname` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  PRIMARY KEY (`reg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `fname`, `lname`, `email`, `password`) VALUES
(1, '', '', '', ''),
(2, 'koko', 'okon', 'jnn@haoo.com', '123'),
(3, 'kolo', 'jon', 'jnnamoko@gmail.com', '123'),
(4, 'john', 'okon', 'jnnnamoko@yahoo.com', '123'),
(5, 'john', 'okonn', 'jnnamoko@yah.com', '123'),
(6, 'john', 'okon ', 'jnn@yuo.com', '123'),
(7, 'osas', 'osas', 'jnn@hao2o.com', '123'),
(8, 'foo', 'loo', 'd@gmail.com', 'qwe'),
(9, 'udo', 'ugo', 'jnn@haoooo.com', '123'),
(10, 'udoudo', 'dan', 'jnnamokro@yahoo.com', '123'),
(11, 'popop', 'john', 'jnnamoko1@yah.com', '123'),
(12, 'Okon', 'Akpan', 'jn1@yahoo.com', '123'),
(13, 'Okon', 'Akpan', 'jnn2@yahoo.com', '123'),
(14, 'Rita', 'John', 'we@yahoo.com', '123'),
(15, 'Okon', 'John', 'jnnwe@yahoo.com', '123'),
(16, 'joe', 'eess', 'we3@yahoo.com', '123'),
(17, 'wejoe', 'joe', '23@yahoo.com', '123'),
(18, 'ani', 'ani', 'jn@yahoo.com', '123'),
(19, 'joe', 'ndi', 'jnn22@yahho.com', '123'),
(20, 'kokoma', 'ben', 'we23@yahoo.com', '123'),
(21, 'Joseph', 'Nnamoko', 'we34@yahoo.com', '123'),
(22, 'john', 'okon', 'someone@yahoo.com', '123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
