

<?php

include "db.php";

if (isset($_POST['sub']))
{

	$email1=   $_POST['email1'];
	$password1=  $_POST['password1'];

if (strlen($email1)<2 || strlen($password1)<2){
	header('location:index.php');
}else{
	$query= "SELECT * FROM register WHERE email ='$email1' AND password ='$password1' ";
	$querit = mysqli_query($db,$query);
			if(mysqli_num_rows($querit)>=1){
				header('location:complainform.php');
			}else{
				header('location.index.php');
			}

	}
}

?>


<!DOCTYPE HTML>
<html>
<head>
<title>Student Complaint System</title>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- for-mobile-apps -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="E-com Login & signup Forms Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!-- //for-mobile-apps -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<!--Google Fonts-->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
</head>
<body>
<div class="wthree-dot">
	<center> <img src="images/logo.gif" alt="logo" /></center>
	<h1></h1>
	<div class="profile">
		<div class="wrap">
			<div class="content-main">
				<div class="w3ls-subscribe w3ls-subscribe1">
					<h4>already have an account?</h4>
					<p>Provide your Login Details to Submit Complaint and be Served Better.</p>
					<form action="" method="post">
						<input type="email" name="email1" placeholder="Email" required="">
						<input type="password" name="password1" placeholder="Password" required="">
						<input type="submit" name="sub" value="Login"> <br>
						<br><h4><a href="register.php">Click here to register </a> </h4>
					</form>
				</div>
			</div>
			
			<div class="wthree_footer_copy">
			<p>© 2022. All rights reserved | Design by <a href="index.html">Gift Apeh</a></p>
			</div>
		</div>
	</div>
</div>
</body>
</html>