<?php include "db.php";

if($_SERVER['REQUEST_METHOD']=="POST"){
	$fname = ($_POST['fname']);
	$lname = ($_POST['lname']);
    $department = ($_POST['department']);
    $faculty = ($_POST['faculty']);
    $email = ($_POST['email']);
    $phone = ($_POST['phone']);
    $nature_of_complain = ($_POST['nature_of_complain']);
    $complain = ($_POST['complain']);


	$sqlii= "INSERT INTO complain_table(fname, lname, department, faculty, email, phone, nature_of_complain, complain)
	VALUES('$fname', '$lname', '$department', '$faculty', '$email', '$phone', '$nature_of_complain', '$complain')";
	$joe=mysqli_query($db,$sqlii);
		if ($joe) {
		?>
		<script type="text/javascript">
				alert("Complain Added! Response Coming Soon. Thanks");
			</script>

		<?php
		}else{
			?>
		<script type="text/javascript">
				alert("Failed to Submit Complain.");
			</script>

		<?php
		}
		

}
?>


			
<!DOCTYPE html>
<html>
<head>
<title>Student Complaint Form</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Admission Enquiry Form web template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css2/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=News+Cycle:400,700" rel="stylesheet">
</head>
<body>
		<div class="content-w3ls">
			<center> <img src="images/log1.gif" alt="logo" /></center>
			<h1 class="agile-head text-center">Make Your Complain</h1>
			<div class="form-w3layouts">					
				<form action="" method="post">
					<div class="form-control"> 
						<label class="header">First Name <span>:</span></label>
						<input type="text" id="name" name="fname"  required="">
						<div class="clear"></div>
					</div>
					<div class="form-control"> 
						<label class="header">Last Name <span>:</span></label>
						<input type="text" id="name" name="lname"  required="">
						<div class="clear"></div>
					</div>
					<div class="form-control">
							<label class="header" >Department</label>
							<select required name="department">
								<option value="">Select Department</option>
								<option> Crop Science </option>
								<option> Agricultural Economics and Extension </option>
								<option> Food Science and Technology</option>
								<option> English Language and Literature </option>
								<option> History and International Studies </option>
								<option> Theatre and Film Studies </option>
								<option> Early Childhood and Primary Education </option>
								<option> Library and lnformation Science </option>
								<option> Science Education </option>
								<option> Vocational Education </option>
								<option> Computer Science </option>
								<option> Computer Engineering </option>
								<option> Chemistry </option>
								<option> Physics </option>
							</select>
							<div class="clear"></div>
					</div>
						<div class="clear"></div>
					</div>

					<div class="form-control">
							<label class="header" >Faculty</label>
							<select required name="faculty">
								<option> Select Faculty</option>
								<option> Faculty of Arts </option>
								<option> Falcuty of Science </option>
								<option> Faculty of Enginerring</option>
								<option> Faculty of Business & Marketing </option>
							</select>
							<div class="clear"></div>
					</div>
					<div class="form-control">	
						<label class="header">Email Address <span>:</span></label>
						<input type="email" id="email" name="email"  required="">
						<div class="clear"></div>
					</div>
				
					<div class="form-control">	
						<label class="header">Phone Number <span>:</span></label>	
						<input type="tel" id="usrtel" name="phone" required="">
						<div class="clear"></div>
					</div>	
					<div class="form-control">
							<label class="header" >Nature Of Complaint</label>  
							<select required name ="nature_of_complain">
								<option> Select Type Of Complaint</option>
								<option> General Complain</option>
								<option> Departmental Complain </option>
								<option> Faculty Complain</option>
								<option> Report Lecturer</option>
							</select>
							<div class="clear"></div>
					</div>
					<div class="form-control">
						<label class="enquiry">Enter details of your complaint <span>:</span></label>
						<textarea id="message" name="complain"></textarea>
						<div class="clear"></div>
					</div>
					
					<div class="form-control w3ls-end">
						<input type="reset" class="reset" value="Reset">
						<input type="submit" class="register" value="Submit">
						<div class="clear"></div>
					</div>	
				</form>
			</div>
		</div>
		<div class="clear"></div>
		<div class="agileits-w3layouts-copyright text-center">
			<p class="w3ls-copyright">© 2022 &nbsp;Student Complaint Form. All rights reserved | FPI School Project</p>
		</div>	
</body>
</html>

