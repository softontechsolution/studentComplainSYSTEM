<?php include "/header.php"
?>

<div class="clearfix"> </div>
<div class="clearfix"> </div>
<div class="clearfix"> </div>

			<div id="page-wrapper">
				<div class="graphs">

<?php
$query = "SELECT * FROM complain_table WHERE complain_id >= 1";
$run_query = mysqli_query($db, $query);
while ($row = mysqli_fetch_assoc($run_query)) {
	$complain_id = $row['complain_id'];
    $fname = $row['fname'];
    $lname = $row['lname'];
    $department = $row['department'];
    $faculty = $row['faculty'];
    $email = $row['email'];
    $phone = $row['phone'];
    $nature_of_complain = $row['nature_of_complain'];
    $complain = $row['complain'];
if ($complain_id < 1 ) {
echo "No Complain";
} else {


?>
				
						<div class="col-md-12 span_20">
							<div class="activity_box">
								<h3>Complains</h3>
								<div class="scrollbar scrollbar1" id="style-2">
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/1.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="attend.html"><?php echo $fname.$lname;
											?></a></h5>
											<p><?php echo $complain
											?></p>
										</div>
										<?php }} ?>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div>
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/5.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="#">Andrew Jos</a></h5>
											<p>Hey ! There I'm available.</p>
										</div>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div>
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/3.png" class="img-responsive" alt=""></div>
										<div class="col-xs-7 activity-desc">
											<h5><a href="#">Adom Smith</a></h5>
											<p>Hey ! There I'm available.</p>
										</div>
										<div class="col-xs-2 activity-desc1"><h6>13:40 PM</h6></div>
										<div class="clearfix"> </div>
									</div>
									<div class="activity-row">
										<div class="col-xs-3 activity-img"><img src="images/4.png" class="img-responsive" alt=""></div>

										
							</div>
						</div>
					

						<div class="clearfix"> </div>
						
					
				</div>
			</div>
		</div>
		<!--footer section start-->
			<footer>
			<p>© 2022. All rights reserved | Design by <a href="index.html">Gift Apeh</a></p>
			</footer>
        <!--footer section end-->
	</section>
	
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>