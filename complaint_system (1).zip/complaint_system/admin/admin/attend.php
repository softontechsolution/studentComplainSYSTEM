<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php include"../db.php";
 ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Easy Admin Panel an Admin Panel Category Flat Bootstrap Responsive Website Template | Inbox :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Easy Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!----webfonts--->
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<!---//webfonts---> 
 <!-- Meters graphs -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- Placed js at the end of the document so the pages load faster -->

</head> 
   
 <body class="sticky-header left-side-collapsed"  onload="initMap()">
    <section>
    <!-- left side start-->
		<div class="left-side sticky-left-side">

			<!--logo and iconic logo start-->
			<div class="logo">
				<h1><a href="index.html">Easy <span>Admin</span></a></h1>
			</div>
			<div class="logo-icon text-center">
				<a href="index.html"><i class="lnr lnr-home"></i> </a>
			</div>

			<!--logo and iconic logo end-->
			<div class="left-side-inner">

				<!--sidebar nav start-->
					<ul class="nav nav-pills nav-stacked custom-nav">
						<li class="active"><a href="index.php"><i class="lnr lnr-power-switch"></i><span>Dashboard</span></a></li>
						<li class="menu-list">
							<a href="#"><i class="lnr lnr-cog"></i>
								<span>Complains</span></a>
								<ul class="sub-menu-list">
									<li><a href="view_complain.php">Total Complains</a> </li>
									<li><a href="view_complain.php">Unresponded Complains</a></li>
									<li><a href="sign-up.html">Add Staff</a></li>
									<li><a href="admin/indexx.php">Log Out</a></li>
								</ul>
						
				<!--sidebar nav end-->
			</div>
		</div>
    <!-- left side end-->
    
    <!-- main content start-->
		<div class="main-content">
			<!-- header-starts -->
			<div class="header-section">
			 
			<!--toggle button start-->
			<a class="toggle-btn  menu-collapsed"><i class="fa fa-bars"></i></a>
			<!--toggle button end-->

			<!--notification menu start -->
			
			<!--notification menu end -->
			</div>
	<!-- //header-ends -->
			<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Repond</h3>

				
						<div class="col-md-8 col-md-offset-2 span_12">
							<div class="activity_box activity_box1">
								<h3>Repond to User</h3>
								<div class="scrollbar" id="style-2">
										<?php

											if(isset($_GET['complainer_id'])){
												$get_complainer_id = $_GET['complainer_id'];
											 	$query = "SELECT * FROM complain_table WHERE complain_id = '".$get_complainer_id ."' AND attended != '0' AND attended='1'";
												$run_query = mysqli_query($db, $query);
												$row = mysqli_fetch_assoc($run_query);
												$complain_id = $row['complain_id'];
									    		$fname = $row['fname'];
									    		$complain = $row['complain'];
									
										?>


									<div class="activity-row activity-row1">
										<div class="col-xs-3 activity-img"><?php echo $complain_id ?><span>10:00 PM</span></div>
										<div class="col-xs-5 activity-img1">
											<div class="activity-desc-sub">
												<h5><?php echo $fname; ?></h5>
												<p><?php echo $complain;  ?></p>
											</div>
										</div>
										<div class="col-xs-4 activity-desc1"></div>
										<div class="clearfix"> </div>
									</div>
									<?php }?>

									<?php
											if(isset($_GET['complainer_id'])){
												$complain_id = $_GET['complainer_id'];
												$query = "SELECT * FROM complain_table WHERE complain_id='".$complain_id."'";
												$run_query = mysqli_query($db, $query);
												if($run_query){
										$row = mysqli_fetch_assoc($run_query);
										$complain_id = $row['complain_id'];
									    $complain_attended = $row['complain_attended'];
									    	$msg = $complain_attended;
									    }else{
									    	echo "data cannot be fetch";
									    }
											
									
										?>
									
									<div class="activity-row activity-row1">
										<div class="col-xs-2 activity-desc1"></div>
										<div class="col-xs-7 activity-img2">
											<div class="activity-desc-sub1">
												<h5>Admin Anonymous</h5>
												<p><?php echo $msg; ?></p>
											</div>
										</div>
										<div class="col-xs-3 activity-img"><p>Admin respond</p><span>10:02 PM</span></div>
										<div class="clearfix"> </div>
									</div>
									<?php }?>
									
								</div>
								<?php
											if(isset($_POST['obinna']) && isset($_GET['complainer_id'])){
												$complain_id = $_GET['complainer_id'];
												$complain = $_POST['complainer'];
												$query = "UPDATE complain_table SET complain_attended = '".$complain."' , attended='1' WHERE complain_id = '".$complain_id."'";
												$update = mysqli_query($db,$query);
												if($update){
														echo 'Refresh';
												}
											}
									
										?>
								<form action="" method="post">
									<input type="text" value="" placeholder="Respond to complain here" name="complainer" required="">
									<input type="submit" value="Send" name="obinna" required="">		
								</form>
							</div>
						</div>
					

						<div class="clearfix"> </div>
						
					
				</div>
			</div>
		</div>
		<!--footer section start-->
			<footer>
			   
			</footer>
        <!--footer section end-->
	</section>
	
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>